package com.example.kontrakan_bangoing

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
