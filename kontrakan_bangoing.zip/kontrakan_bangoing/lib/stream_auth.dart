import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:kontrakan_bangoing/tabbarcomponent.dart';

import '../bloc/datauser/datauser_bloc.dart';
import 'error_page.dart';
import 'loading.dart';
import 'welcome.dart';

class StreamAuth extends StatefulWidget {
  const StreamAuth({
    Key? key,
  }) : super(key: key);

  @override
  State<StreamAuth> createState() => _StreamAuthState();
}

class _StreamAuthState extends State<StreamAuth> {
  @override
  Widget build(BuildContext context) {
    // final dp = Provider.of<DataProvider>(context);

    return StreamBuilder(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (ctx, userSnapshot) {
          if (userSnapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(
              backgroundColor: Colors.white,
              body: Center(
                child: SizedBox(
                  width: 100,
                  height: 100,
                  child: CircularProgressIndicator(
                    color: Colors.blue,
                  ),
                ),
              ),
            );
          }
          if (userSnapshot.hasData) {
            // return const TabbarComponent();
            final user = FirebaseAuth.instance.currentUser;

            // final Stream<QuerySnapshot> _usersStream =
            //     FirebaseFirestore.instance.collection('users').snapshots();

            // Stream documentStream = FirebaseFirestore.instance
            //     .collection('users')
            //     .doc(user?.uid)
            //     .snapshots();
            // return ElevatedButton(onPressed:  () async =>
            //                       await FirebaseAuth.instance.signOut(), child: Text('logout'));
            return StreamBuilder<DocumentSnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('users')
                  .doc(user?.uid)
                  .snapshots(),
              builder: (BuildContext context,
                  AsyncSnapshot<DocumentSnapshot> snapshot) {
                if (snapshot.hasError) {
                  return const ErrorPage();
                }

                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Scaffold(
                      backgroundColor: Colors.white,
                      body: Center(child: Loading()));
                }
                Map<String, dynamic> data =
                    snapshot.data!.data() as Map<String, dynamic>;

                if (snapshot.hasData && snapshot.data?.data() != null) {
                  // print('data nya' + data['username'].toString());

                  if (data['name'] != null) {
                    context.read<DatauserBloc>().add(DatauserEventFetch(
                          name: data['name'],
                          email: data['email'],
                          photo: data['photo_url'],
                        ));
                  }
                }

                return TabbarComponent();
              },
            );
          }

          return const Welcome();

          // return const Login();
        });
  }
}
