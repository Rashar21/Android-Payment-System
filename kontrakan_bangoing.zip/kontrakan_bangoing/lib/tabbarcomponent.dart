import 'package:flutter/material.dart';
import 'package:kontrakan_bangoing/home.dart';
import 'package:kontrakan_bangoing/komplain.dart';
import 'package:kontrakan_bangoing/payment.dart';
import 'package:kontrakan_bangoing/profile.dart';

import '../theme.dart';

class TabbarComponent extends StatefulWidget {
  const TabbarComponent({Key? key}) : super(key: key);

  @override
  State<TabbarComponent> createState() => _TabbarComponentState();
}

// int countListChat = 90;

class _TabbarComponentState extends State<TabbarComponent> {
  int _selectedIndex = 3;
  // static const TextStyle optionStyle =
  //     TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  static final List<Widget> _widgetOptions = <Widget>[
    const Home(),
    const Payment(),
    const Komplain(),
    const Profile(),
    // const Location(),
    // Column(
    //   children: const [
    //     CartPage(),
    //   ],
    // ),
    // const TabbarComponent(),
    // // const Service(),
    // const Profile(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        // drawer: const AppDrawer(),

        resizeToAvoidBottomInset: false,
        // appBar: AppBar(
        //   title: Align(
        //     alignment: Alignment.topLeft,
        //     child: Text(
        //       "SEKOLAH",
        //       style: TextStyle(
        //         fontWeight: FontWeight.bold,
        //         color: Colors.white,
        //         fontSize: 25,
        //       ),
        //     ),
        //   ),
        //   centerTitle: true,
        //   backgroundColor: kGreenColor,
        //   elevation: 0,
        // ),
        // drawer:
        //     //drawer sample
        //     Drawer(
        //         child: ListView(children: const <Widget>[
        //   UserAccountsDrawerHeader(
        //     accountName: Text('Halo Bengkel'),
        //     accountEmail: Text('d'),
        //   )
        // ])),
        body: Center(
          child: _widgetOptions.elementAt(_selectedIndex),
        ),
        // floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        // floatingActionButton: Container(
        //   // color: Colors.red,
        //   padding: EdgeInsets.all(8),
        //   margin: EdgeInsets.all(4),
        //   child: FloatingActionButton(
        //     child: const Icon(Icons.add),
        //     onPressed: () {
        //       // Overlay.of(context).insert(entry);
        //       setState(() {
        //         _selectedIndex = 2;
        //       });
        //     },
        //   ),
        // ),
        bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Colors.white,
          //fixed size
          // type: BottomNavigationBarType.fixed,
          items: <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.payment),
              label: 'Bayar',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.warning),
              label: 'Komplain',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: 'PROFIL',
            ),
          ],
          currentIndex: _selectedIndex,
          selectedItemColor: kGreenColor,
          unselectedItemColor: Colors.black,
          onTap: _onItemTapped,
          type: BottomNavigationBarType.fixed,
          elevation: 10,
        ),
      ),
    );
  }
}
