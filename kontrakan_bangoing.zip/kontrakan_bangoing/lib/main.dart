import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:kontrakan_bangoing/stream_auth.dart';

import 'bloc/Islogin/islogin_bloc.dart';
import 'bloc/activeindexwebmenu/activeindexwebmenu_bloc.dart';
import 'bloc/datauser/datauser_bloc.dart';
import 'bloc/isloadinglogin/isloadinglogin_bloc.dart';
import 'theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => IsloadingloginBloc(),
        ),
        BlocProvider(
          create: (context) => IsloginBloc(),
        ),
        BlocProvider(
          create: (context) => DatauserBloc(),
        ),
        BlocProvider(
          create: (context) => ActiveindexwebmenuBloc(),
        ),
      ],
      child: MaterialApp(
          color: kGreenColor,
          debugShowCheckedModeBanner: false,
          title: 'BANK OING',
          theme: ThemeData.light().copyWith(
            backgroundColor: Colors.white,
            bottomSheetTheme: const BottomSheetThemeData(
              backgroundColor: Colors.blue,
            ),
            scaffoldBackgroundColor: Colors.white,
            textTheme: GoogleFonts.poppinsTextTheme(Theme.of(context).textTheme)
                .apply(bodyColor: Colors.black),
            canvasColor: Colors.blue.shade700,
          ),
          home: const StreamAuth()),
    );
  }
}
