import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import '../theme.dart';
import 'custom_text_field.dart';
import 'signin.dart';
import 'stream_auth.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({Key? key}) : super(key: key);

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final TextEditingController _nameCtl = TextEditingController();
  final TextEditingController _emailCtl = TextEditingController();
  final TextEditingController _passwordCtl = TextEditingController();
  // final TextEditingController _hobbyCtl = TextEditingController();
  final TextEditingController _fotoCtl = TextEditingController();
  String? fotopath;
  CollectionReference users = FirebaseFirestore.instance.collection('users');
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  // Validasi input user
  bool isValid() {
    if (_nameCtl.text.isEmpty) {
      return false;
    } else if (_emailCtl.text.isEmpty) {
      return false;
    } else if (_passwordCtl.text.isEmpty) {
      return false;
    } else if (_fotoCtl.text.isEmpty) {
      return false;
    }

    return true;
  }

  @override
  void dispose() {
    _nameCtl.dispose();
    _emailCtl.dispose();
    _passwordCtl.dispose();
    _fotoCtl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Future takefilefoto() async {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        allowedExtensions: ['jpg', 'jpeg', 'png'],
        type: FileType.custom,
      );

      if (result != null) {
        // File file = File(result.files.single.path);

        fotopath = result.files.single.path;
        setState(() {
          _fotoCtl.text = result.files.first.name;
        });
      } else {
        // print('cancel');
        // User canceled the picker
      }

      return _fotoCtl.text;
    }

    Future<dynamic> _register() async {
      // context.read<IsloadingloginBloc>().add(LoadingLoginStartEvent());
      if (_nameCtl.text.isEmpty ||
          _emailCtl.text.isEmpty ||
          _passwordCtl.text.isEmpty ||
          _fotoCtl.text.isEmpty) {
        // context.read<IsloadingloginBloc>().add(LoadingLoginSelesaiEvent());

        //if not show snackbar
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Data belum lengkap'),
            duration: Duration(seconds: 2),
          ),
        );
      } else {
        setState(() {
          _isLoading = true;
        });
        try {
          UserCredential userCredential = await FirebaseAuth.instance
              .createUserWithEmailAndPassword(
                  email: _emailCtl.text, password: _passwordCtl.text);
          final uid = userCredential.user?.uid;

          final ref = FirebaseStorage.instance
              .ref()
              .child('photo_user')
              .child('$uid.jpg');

          // await ref.putData(coverfile!);
          // await ref.putFile(File(fotopath!));
          // await ref.putData(await testCompressFile(File(fotopath!)));
          // final url = await ref.getDownloadURL();
          await ref.putFile(File(fotopath!));
          final url = await ref.getDownloadURL();

          return users.doc(uid).set({
            'name': _nameCtl.text,
            'email': _emailCtl.text,
            'password': _passwordCtl.text,
            "id": uid,
            "photo_url": url,
          }).then((value) {
            setState(() {
              _isLoading = false;
            });

            //show snackbar
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Register berhasil'),
                duration: Duration(seconds: 2),
              ),
            );
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => const StreamAuth(),
              ),
            );
            // Navigator.pop(context);
          });
          // .then((value) => print("User Added"))
          // .catchError((error) => print("Failed to add user: $error"));
        } on FirebaseAuthException catch (e) {
          if (e.code == 'weak-password') {
            // print('The password provided is too weak.');
          } else if (e.code == 'email-already-in-use') {
            // print('The account already exists for that email.');
            showDialog(
              context: context,
              builder: (ctx) => AlertDialog(
                // backgroundColor: bluedefault(),
                title: const Text('Email already in use'),
                content:
                    const Text('The account already exists for that email.'),
                actions: <Widget>[
                  ElevatedButton(
                    child: const Text('Okay'),
                    onPressed: () {
                      setState(() {
                        _isLoading = false;
                      });
                      Navigator.of(ctx).pop();
                    },
                  )
                ],
              ),
            );
          } else {
            showDialog(
              context: context,
              builder: (ctx) => AlertDialog(
                // backgroundColor: bluedefault(),
                title: const Text('Email cannot use'),
                content: const Text('The email cannot use.'),
                actions: <Widget>[
                  ElevatedButton(
                    child: const Text('Okay'),
                    onPressed: () {
                      setState(() {
                        _isLoading = false;
                      });
                      Navigator.of(ctx).pop();
                    },
                  )
                ],
              ),
            );
          }
        } catch (e) {
          //showdialog error
          // context.read<IsloadingloginBloc>().add(LoadingLoginSelesaiEvent());
          setState(() {
            _isLoading = false;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error: $e'),
              duration: const Duration(seconds: 2),
            ),
          );
        }
      }
    }

    return SafeArea(
      child: Scaffold(
        body: ListView(
          children: [
            const SizedBox(
              height: 50.0,
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  const SizedBox(height: 20),
                  Form(
                    key: _formKey,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        GestureDetector(
                          onTap: () =>
                              takefilefoto().then((value) => setState(() {
                                    _fotoCtl.text = value;
                                  })),
                          child: Container(
                            margin: const EdgeInsets.only(
                              bottom: 20.0,
                            ),
                            height: 150,
                            width: 310,
                            decoration: BoxDecoration(
                                color: kSemiBlackColor,
                                borderRadius: BorderRadius.circular(10)),
                            child: Column(
                                // ignore: prefer_const_literals_to_create_immutables
                                children: [
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  const Icon(
                                    Icons.image,
                                    size: 50,
                                  ),
                                  Text(
                                    'Pilih foto Profile',
                                    style:
                                        TextStyle(color: HexColor('#889098')),
                                  ),
                                  const SizedBox(
                                    height: 5,
                                  ),
                                  TextField(
                                    textAlign: TextAlign.center,
                                    enabled: false,
                                    controller: _fotoCtl,
                                    obscureText: false,
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                          borderSide: const BorderSide(
                                            width: 0,
                                            style: BorderStyle.none,
                                          ),
                                          borderRadius:
                                              BorderRadius.circular(10),
                                        ),
                                        hintText: "Cari Foto",
                                        hintStyle: kBlackTextStyle.copyWith(
                                            fontWeight: regular,
                                            fontSize: 16,
                                            color: kGreenColor,
                                            decoration:
                                                TextDecoration.underline)),
                                  ),
                                ]),
                          ),
                        ),
                        CustomTextField(
                          nameTextField: 'Nama Lengkap',
                          iconTextField: Icon(
                            Icons.person,
                            color: HexColor('#889098'),
                            size: 30,
                          ),
                          controller: _nameCtl,
                        ),
                        CustomTextField(
                          nameTextField: 'Email',
                          iconTextField: Icon(
                            Icons.email,
                            size: 30,
                            color: HexColor('#889098'),
                          ),
                          controller: _emailCtl,
                        ),
                        CustomTextField(
                          nameTextField: 'Password',
                          iconTextField: Icon(
                            Icons.lock,
                            size: 30,
                            color: HexColor('#889098'),
                          ),
                          controller: _passwordCtl,
                          isPassword: true,
                        ),
                        const SizedBox(height: 30),
                      ],
                    ),
                  ),
                  Container(
                    width: double.infinity,
                    height: 45,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: kGreenColor,
                    ),
                    child: TextButton(
                        onPressed: _register,
                        child: _isLoading
                            ? const CircularProgressIndicator(
                                color: Colors.white,
                              )
                            : Text(
                                'Daftar',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyLarge!
                                    .copyWith(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white),
                              )),
                  ),
                  TextButton(
                      onPressed: () => Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const SignInPage(),
                            ),
                          ),
                      //pop
                      // () => Navigator.pop(context),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Sudah ada akun? ',
                            style: kGreyTextStyle.copyWith(
                                fontWeight: light, color: kGreenColor),
                          ),
                          Text(
                            'Masuk Sekarang',
                            style: kGreyTextStyle.copyWith(
                                decoration: TextDecoration.underline,
                                fontWeight: regular,
                                color: kGreenColor),
                          ),
                        ],
                      )),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
