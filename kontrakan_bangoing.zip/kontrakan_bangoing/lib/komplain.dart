import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:kontrakan_bangoing/theme.dart';

class Komplain extends StatefulWidget {
  const Komplain({super.key});

  @override
  State<Komplain> createState() => _KomplainState();
}

class _KomplainState extends State<Komplain> {
  final TextEditingController controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    String uid = FirebaseAuth.instance.currentUser!.uid;
    Future<void> addUser() {
      String date = DateTime.now().toString();
      // Call the user's CollectionReference to add a new user
      return FirebaseFirestore.instance
          .collection('komplain')
          .doc(uid + date)
          .set({
        'docnya': uid + date,
        'isi': controller.text,
        'uid': uid,
      }).then((value) {
        //showdialog
        controller.clear();
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            backgroundColor: Colors.white,
            title: const Text(
              'Berhasil!',
            ),
            content: Text('Komplain anda telah terkirim'),
            actions: <Widget>[
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                ),
                child: const Text('Ok'),
                onPressed: () {
                  Navigator.of(ctx).pop();
                },
              )
            ],
          ),
        );
      }).catchError((error) => print("Failed to add user: $error"));
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Komplain'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
                'Beritahu kami jika ada yang menggangu anda terkait kontrakan ya!'),
            SizedBox(height: 20),
            TextFormField(
              maxLines: 5,
              cursorColor: Colors.green,
              controller: controller,
              decoration: InputDecoration(
                labelText: 'Komplain',
                hintStyle: kBlackTextStyle.copyWith(
                  fontWeight: regular,
                  fontSize: 16,
                ),
                // filled: true,
                fillColor: kSemiBlackColor,
                // suffixIcon: iconTextField,
                // suffixIconColor: const Color.fromARGB(255, 124, 126, 124),
                // focusedBorder: OutlineInputBorder(
                //   borderSide: const BorderSide(
                //     width: 1,
                //     color: Colors.white,
                //   ),
                //   borderRadius: BorderRadius.circular(10),
                // ),
                border: OutlineInputBorder(
                  borderSide: const BorderSide(
                    width: 2,
                    style: BorderStyle.none,
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(onPressed: addUser, child: Text('Kirim Komplain')),
            ElevatedButton(
                onPressed: () {
                  controller.clear();
                },
                child: Text('Bersihkan Komplain')),
          ],
        ),
      ),
    );
  }
}
