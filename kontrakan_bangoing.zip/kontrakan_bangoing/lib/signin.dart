import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';

import 'custom_text_field.dart';
import 'sign_up_page.dart';
import 'stream_auth.dart';
import 'theme.dart';

class SignInPage extends StatefulWidget {
  const SignInPage({Key? key}) : super(key: key);

  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  final TextEditingController _emailC = TextEditingController();
  final TextEditingController _passwordC = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  @override
  void dispose() {
    _emailC.dispose();
    _passwordC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    void _showErrorDialog(String message) {
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: Colors.white,
          title: const Text(
            'Tidak benar!',
          ),
          content: Text(message),
          actions: <Widget>[
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
              ),
              child: const Text('Ok'),
              onPressed: () {
                Navigator.of(ctx).pop();
              },
            )
          ],
        ),
      );
    }

    Future<void> _submitfn() async {
      //if check email and password is empty
      if (_emailC.text.isEmpty || _passwordC.text.isEmpty) {
        _showErrorDialog('Please enter email and password');
        return;
      }
      setState(() {
        _isLoading = true;
      });

      // context.read<IsloadingloginBloc>().add(LoadingLoginStartEvent());

      try {
        await FirebaseAuth.instance
            .signInWithEmailAndPassword(
                email: _emailC.text, password: _passwordC.text)
            .then((value) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => const StreamAuth(),
            ),
          );
        });

        // context.read<IsloginBloc>().add(UserLoginEvent());
      } on FirebaseAuthException catch (e) {
        var errorMessage = 'Authentication failed';
        if (e.code == 'user-not-found') {
          errorMessage = 'No user found for that email.';
        } else if (e.code == 'wrong-password') {
          errorMessage =
              'Kata sandi salah coba ingat-ingat lagi atau lupa password';
        }
        setState(() {
          _isLoading = false;
        });
        // context.read<IsloginBloc>().add(UserSignoutEvent());
        // ds.isLogin = false;
        _showErrorDialog(errorMessage);
      }
      // ds.isLoadingLogin = false;
      // context.read<IsloadingloginBloc>().add(LoadingLoginSelesaiEvent());
    }

    return Scaffold(
        body: ListView(children: [
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(
              height: 30,
            ),
            const SizedBox(
              height: 10.0,
            ),
            Text(
              'Sign In',
              style: Theme.of(context)
                  .textTheme
                  .headlineSmall!
                  .copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Form(
              key: _formKey,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    CustomTextField(
                      nameTextField: 'Email',
                      iconTextField: Icon(
                        Icons.email,
                        size: 30,
                        color: HexColor('#889098'),
                      ),
                      controller: _emailC,
                    ),
                    CustomTextField(
                      nameTextField: 'Password',
                      iconTextField: Icon(
                        Icons.lock,
                        size: 30,
                        color: HexColor('#889098'),
                      ),
                      controller: _passwordC,
                      isPassword: true,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Container(
              width: double.infinity,
              height: 55,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: kGreenColor,
              ),
              child: TextButton(
                  onPressed: _submitfn,
                  child: _isLoading
                      ? const CircularProgressIndicator(
                          color: Colors.white,
                        )
                      : Padding(
                          padding: const EdgeInsets.only(left: 10, right: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Sign In',
                                style: Theme.of(context)
                                    .textTheme
                                    .titleLarge!
                                    .copyWith(color: Colors.white),
                              ),
                              const Icon(
                                Icons.arrow_forward,
                                color: Colors.white,
                              )
                            ],
                          ),
                        )),
            ),
            const SizedBox(
              height: 10.0,
            ),
            TextButton(
                onPressed:
                    // () => context.read<ActiveindexwebmenuBloc>().add(
                    //     ChangeactiveindexwebmenuEvent(activeindex: 'Register')),
                    () => Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const SignUpPage(),
                          ),
                        ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Belum ada akun?',
                      style: kGreyTextStyle.copyWith(
                          fontWeight: light, color: HexColor('#95A1B8')),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    Text(
                      'Daftar Sekarang',
                      style: kGreyTextStyle.copyWith(
                          fontWeight: regular, color: kGreenColor),
                    ),
                  ],
                )),
            const SizedBox(
              height: 10.0,
            ),
          ],
        ),
      ),
    ]));
  }
}
