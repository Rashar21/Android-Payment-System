import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hexcolor/hexcolor.dart';

import '../bloc/datauser/datauser_bloc.dart';
import 'theme.dart';

class Payment extends StatefulWidget {
  const Payment({
    super.key,
  });

  @override
  State<Payment> createState() => _PaymentState();
}

class _PaymentState extends State<Payment> {
  final TextEditingController _fotoCtl = TextEditingController();
  String uid = FirebaseAuth.instance.currentUser!.uid;
  String? fotopath;
  bool _isLoading = false;
  CollectionReference users = FirebaseFirestore.instance.collection('payment');

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    String namauser =
        context.select<DatauserBloc, String>((value) => value.state.name);
    String email =
        context.select<DatauserBloc, String>((value) => value.state.email);

    Future takefilefoto() async {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        allowedExtensions: ['jpg', 'jpeg', 'png'],
        type: FileType.custom,
      );

      if (result != null) {
        // File file = File(result.files.single.path);

        fotopath = result.files.single.path;
        setState(() {
          _fotoCtl.text = result.files.first.name;
        });
      } else {
        // print('cancel');
        // User canceled the picker
      }

      return _fotoCtl.text;
    }

    Future<dynamic> send() async {
      String date = DateTime.now().toString();
      // context.read<IsloadingloginBloc>().add(LoadingLoginStartEvent());
      if (_fotoCtl.text.isEmpty) {
        // context.read<IsloadingloginBloc>().add(LoadingLoginSelesaiEvent());

        //if not show snackbar
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Data belum lengkap'),
            duration: Duration(seconds: 2),
          ),
        );
      } else {
        setState(() {
          _isLoading = true;
        });
        try {
          final ref = FirebaseStorage.instance
              .ref()
              .child('photo_user')
              .child('$date.jpg');

          // await ref.putData(coverfile!);
          // await ref.putFile(File(fotopath!));
          // await ref.putData(await testCompressFile(File(fotopath!)));
          // final url = await ref.getDownloadURL();
          await ref.putFile(File(fotopath!));
          final url = await ref.getDownloadURL();

          return users.doc(uid + date).set({
            'docnya': uid + date,
            "id": uid,
            "bukti": url,
          }).then((value) {
            setState(() {
              _isLoading = false;
            });

            //show snackbar
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Berhasil'),
                duration: Duration(seconds: 2),
              ),
            );

            // Navigator.pop(context);
          });
          // .then((value) => print("User Added"))
          // .catchError((error) => print("Failed to add user: $error"));
        } catch (e) {
          //showdialog error
          // context.read<IsloadingloginBloc>().add(LoadingLoginSelesaiEvent());
          setState(() {
            _isLoading = false;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error: $e'),
              duration: const Duration(seconds: 2),
            ),
          );
        }
      }
    }

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text('Bayar'),
        ),
        backgroundColor: Colors.grey.shade200,
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              'assets/logo.jpeg',
              width: size.width,
              fit: BoxFit.fill,
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Bank Transfer',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                  ),
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Text('BCA 292992929 - Kontrakan Bang Oing')),
                  GestureDetector(
                    onTap: () => takefilefoto().then((value) => setState(() {
                          _fotoCtl.text = value;
                        })),
                    child: Container(
                      margin: const EdgeInsets.only(
                        bottom: 20.0,
                      ),
                      height: 150,
                      width: 310,
                      decoration: BoxDecoration(
                          color: kSemiBlackColor,
                          borderRadius: BorderRadius.circular(10)),
                      child: Column(
                          // ignore: prefer_const_literals_to_create_immutables
                          children: [
                            const SizedBox(
                              height: 10,
                            ),
                            const Icon(
                              Icons.image,
                              size: 50,
                            ),
                            Text(
                              'Upload Bukti Transfer',
                              style: TextStyle(color: HexColor('#889098')),
                            ),
                            const SizedBox(
                              height: 5,
                            ),
                            TextField(
                              textAlign: TextAlign.center,
                              enabled: false,
                              controller: _fotoCtl,
                              obscureText: false,
                              decoration: InputDecoration(
                                  border: OutlineInputBorder(
                                    borderSide: const BorderSide(
                                      width: 0,
                                      style: BorderStyle.none,
                                    ),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  hintText: "",
                                  hintStyle: kBlackTextStyle.copyWith(
                                      fontWeight: regular,
                                      fontSize: 16,
                                      color: kGreenColor,
                                      decoration: TextDecoration.underline)),
                            ),
                          ]),
                    ),
                  ),
                  SizedBox(height: 20),
                  Container(
                    width: double.infinity,
                    height: 45,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: kGreenColor,
                    ),
                    child: TextButton(
                        onPressed: send,
                        child: _isLoading
                            ? const CircularProgressIndicator(
                                color: Colors.white,
                              )
                            : Text(
                                'Confirm Payment',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyLarge!
                                    .copyWith(color: Colors.white),
                              )),
                  ),
                  const SizedBox(
                    height: 20.0,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
