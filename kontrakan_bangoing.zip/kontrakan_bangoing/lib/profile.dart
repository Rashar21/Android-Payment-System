import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'bloc/datauser/datauser_bloc.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  int index = 0;
  @override
  Widget build(BuildContext context) {
    String uid = FirebaseAuth.instance.currentUser!.uid;
    String namauser =
        context.select<DatauserBloc, String>((value) => value.state.name);
    String fotouser =
        context.select<DatauserBloc, String>((value) => value.state.photo);

    Future<void> batchDelete() {
      WriteBatch batch = FirebaseFirestore.instance.batch();

      return FirebaseFirestore.instance
          .collection('komplain')
          .where('uid', isEqualTo: uid)
          .get()
          .then((querySnapshot) {
        for (var document in querySnapshot.docs) {
          batch.delete(document.reference);
        }

        return batch.commit();
      });
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
        actions: [
          IconButton(
            onPressed: () {
              FirebaseAuth.instance.signOut();
            },
            icon: Icon(Icons.logout),
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                elevation: 15,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text(
                        namauser,
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      CircleAvatar(
                        radius: 50,
                        backgroundImage: NetworkImage(fotouser),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: 30),
            Text('Komlain yang sudah dikirim'),
            SizedBox(height: 30),

            //buatkan tombol komplain dan history pembayaran secara row
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor:
                            index == 0 ? Colors.blue : Colors.white,
                      ),
                      onPressed: () {
                        setState(() {
                          index = 0;
                        });
                      },
                      child: Text(
                        'Komplain',
                        style: TextStyle(
                            color: index == 0 ? Colors.white : Colors.blue),
                      ),
                    ),
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: index == 1 ? Colors.blue : Colors.white,
                    ),
                    onPressed: () {
                      setState(() {
                        index = 1;
                      });
                    },
                    child: Text(
                      'History Pembayaran',
                      style: TextStyle(
                          color: index == 1 ? Colors.white : Colors.blue),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 30),

            if (index == 0)
              StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('komplain')
                    .where('uid', isEqualTo: uid)
                    .snapshots(),
                builder: (BuildContext context,
                    AsyncSnapshot<QuerySnapshot> snapshot) {
                  if (snapshot.hasError) {
                    return Text('Something went wrong');
                  }

                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Text("Loading");
                  }

                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children:
                          snapshot.data!.docs.map((DocumentSnapshot document) {
                        Map<String, dynamic> data =
                            document.data()! as Map<String, dynamic>;
                        return Card(
                          elevation: 5,
                          child: ListTile(
                            title: Text(
                              data['isi'],
                              style: Theme.of(context)
                                  .textTheme
                                  .titleLarge!
                                  .copyWith(color: Colors.black),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  );
                },
              ),
            if (index == 0)
              ElevatedButton(onPressed: batchDelete, child: Text('Clear Komplain')),
            if (index == 1)
              StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('payment')
                    .where('id', isEqualTo: uid)
                    .snapshots(),
                builder: (BuildContext context,
                    AsyncSnapshot<QuerySnapshot> snapshot) {
                  if (snapshot.hasError) {
                    return Text('Something went wrong');
                  }

                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Text("Loading");
                  }

                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children:
                          snapshot.data!.docs.map((DocumentSnapshot document) {
                        Map<String, dynamic> data =
                            document.data()! as Map<String, dynamic>;
                        return Card(
                            elevation: 5, child: Image.network(data['bukti']));
                      }).toList(),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}
