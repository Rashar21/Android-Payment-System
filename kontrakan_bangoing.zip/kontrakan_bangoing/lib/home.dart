import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
      ),
      body: SingleChildScrollView(
        child: Wrap(
          spacing: 20,
          runSpacing: 20,
          children: [
            Image.asset('assets/1.jpeg'),
            Image.asset('assets/2.jpeg'),
            Image.asset('assets/3.jpeg'),
          ],
        ),
      ),
    );
  }
}
