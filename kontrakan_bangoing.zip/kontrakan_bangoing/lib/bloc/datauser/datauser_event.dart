part of 'datauser_bloc.dart';

@immutable
abstract class DatauserEvent {}

class DatauserEventFetch extends DatauserEvent {
  final String name, email, photo;
  DatauserEventFetch({
    required this.name,
    required this.email,
    required this.photo,
  });
}
