part of 'datauser_bloc.dart';

@immutable
abstract class DatauserState {
  final String name, email, photo;

  const DatauserState(this.name, this.email, this.photo);
}

class DatauserInitial extends DatauserState {
  const DatauserInitial()
      : super(
          "sample name",
          "sample email",
          "sample photo",
        );
}

class DatauserLoad extends DatauserState {
  const DatauserLoad(
    String name,
    String email,
    String photo,
  ) : super(
          name,
          email,
          photo,
        );
}
